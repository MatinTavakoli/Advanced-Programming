Format : PNG ( With transparent background )
Dimensions : 50*50 pixels ( Except Logo.png which is exactly 261 * 153 pixels and Icon.png which is exactly 256 * 256 pixels. )

ToolBar bg color : #d0dff8
Main bg color : #e7effb
Left sidebar bg color : #32363f


By MMKH.